
#ifndef MVCAMERAPARA_H_
#define MVCAMERAPARA_H_

#ifndef CXX_PCVPLATFORM_DEF_H
#include "pcvPlatformdef.h"
#endif



#endif /* MVCAMERAPARA_H_ */
