/*
 * @(#)$Id: pcvFeatureDetection.h 1440 2011-12-30 02:47:08Z LvGangXiao $ 
 * @(#) Declaration file of class pcvFeatureDetection
 *
 * (c)  EZ CORPORATION  2015
 * All Rights Reserved.
 */
/** @file   
 * Declaration of pcvFeatureDetection
 * 
 * TO DESC : FILE DETAIL DESCRIPTION, BUT DON'T DESCRIBE CLASS DETAIL HERE.
 */
#ifndef CXX_PCVFEATUREDETECTION_H
#define CXX_PCVFEATUREDETECTION_H




#endif // CXX_PCVFEATUREDETECTION_H
/* EOF */
